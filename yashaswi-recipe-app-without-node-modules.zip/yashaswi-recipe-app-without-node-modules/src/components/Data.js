// id: 1, // must be always unique

export const BiryanisData = [
    {
        id: 1,
        showDetails: false,
        category: "biryani",
        name: "Dum Biryani",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 2,
        showDetails: false,
        category: "biryani",
        name: "Guntur Biryani",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 3,
        showDetails: false,
        category: "biryani",
        name: "Rayalaseema Special Biryani",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 4,
        showDetails: false,
        category: "biryani",
        name: "Paneer Veg Biryani",
        difficulty: "hard",
        ingredients: "Paneer, Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "non-veg"
    },

]

export const RiceItemsData = [
    {
        id: 5,
        showDetails: false,
        category: "riceitems",
        name: "Jira Rice",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 6,
        showDetails: false,
        category: "riceitems",
        name: "Veg Rice",
        difficulty: "easy",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 7,
        showDetails: false,
        category: "riceitems",
        name: "Chicken Rice",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "non-veg"
    },
    {
        id: 8,
        showDetails: false,
        category: "riceitems",
        name: "Paneer Rice",
        difficulty: "hard",
        ingredients: "Paneer, Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },

]

export const CurriesData = [
    {
        id: 9,
        showDetails: false,
        category: "curries",
        name: "Tomato Curry",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 10,
        showDetails: false,
        category: "curries",
        name: "Veg Curry",
        difficulty: "easy",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 11,
        showDetails: false,
        category: "curries",
        name: "Chicken Curry",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "non-veg"
    },
    {
        id: 12,
        showDetails: false,
        category: "curries",
        name: "Paneer Curry",
        difficulty: "hard",
        ingredients: "Paneer, Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },

]

export const SnacksData = [
    {
        id: 9,
        showDetails: false,
        category: "snacks",
        name: "Tomato Sandwitch",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 10,
        showDetails: false,
        category: "snacks",
        name: "Veg Sandwitch",
        difficulty: "easy",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 11,
        showDetails: false,
        category: "snacks",
        name: "Chicken Sandwitch",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "non-veg"
    },
    {
        id: 12,
        showDetails: false,
        category: "snacks",
        name: "Fries",
        difficulty: "hard",
        ingredients: "Paneer, Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },

]

export const MilkShakesData = [
    {
        id: 13,
        showDetails: false,
        category: "milkshakes",
        name: "Oreo Milkshake",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 14,
        showDetails: false,
        category: "milkshakes",
        name: "Strawberry Milkshake",
        difficulty: "easy",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 15,
        showDetails: false,
        category: "milkshakes",
        name: "Choco Milkshake",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 16,
        showDetails: false,
        category: "milkshakes",
        name: "Vanilla Milkshake",
        difficulty: "hard",
        ingredients: "Paneer, Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },

]

export const SweetsData = [
    {
        id: 17,
        showDetails: false,
        category: "sweets",
        name: "Kaju Katli",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 18,
        showDetails: false,
        category: "sweets",
        name: "Kala Khand",
        difficulty: "easy",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 19,
        showDetails: false,
        category: "sweets",
        name: "Milk Cake",
        difficulty: "hard",
        ingredients: "Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },
    {
        id: 20,
        showDetails: false,
        category: "sweets",
        name: "Choco Cake",
        difficulty: "hard",
        ingredients: "Paneer, Lemon, Rice, Water, Chicken, Turmeric ,...",
        type: "veg"
    },

]