import React from 'react'
import './Summary.css'

function Summary() {
    return (
        <div id='summary'>
            <h2>Destination to your Recipe searching journey</h2>
            <p>some description of your coice folks. " Lorem ipsum dolor sit amet, consectetur adipiscing elit. landit nunc dolor, ut volutpat justo eleifend nec. Ut vestibulum risus augue, nec cursus elit condimentum ac".</p>
        </div>
    )
}

export default Summary